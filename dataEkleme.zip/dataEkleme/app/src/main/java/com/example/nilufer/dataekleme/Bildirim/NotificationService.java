package com.example.nilufer.dataekleme.Bildirim;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.IBinder;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;


import com.example.nilufer.dataekleme.Constants;
import com.example.nilufer.dataekleme.R;
import com.example.nilufer.dataekleme.fGosterim;
import com.google.android.gms.maps.model.LatLng;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

public class NotificationService extends Service {

    Context context ;
    Notification notification;
    Timer timer;
    final private String url = "https://us-central1-api1-13f97.cloudfunctions.net/getItems";

    static ArrayList<Integer> myList = new ArrayList<Integer>();
    public static List myList2 = new ArrayList<>();
    static Double lat = null ,alng = null,threshold = null;
    static String flt = null;


    @Override
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);
        lat = intent.getDoubleExtra("lat",0);
        alng = intent.getDoubleExtra("long",0);
        threshold = intent.getDoubleExtra("threshold",0);
        flt = intent.getStringExtra("kategori");
        System.out.println("lat :"+lat+"long"+alng+"threshold : "+threshold);

    }

    @Override
    public IBinder onBind(Intent intent) {


        return null;
    }
    @Override
    public void onCreate() {//Servis startService(); metoduyla çağrıldığında çalışır
        context = getApplicationContext();
        Toast.makeText(this, "Servis Çalıştı.Bu Mesaj Servis Class'dan", Toast.LENGTH_LONG).show();

        timer = new Timer();
        timer.schedule(new TimerTask() {  //her 60 sn de bir bildirimGonder(); metodu çağırılır.
            @Override
            public void run() {
                new arkaplan().execute(url);
            }

        }, 0, 60000);

    }

    class arkaplan extends AsyncTask<String,String,String> {
        protected String doInBackground(String... params) {
            HttpURLConnection connection = null;
            BufferedReader br = null;
            BufferedReader brr = null;

            try {
                URL url = new URL(params[0]);


                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                InputStream is = connection.getInputStream();
                br = new BufferedReader(new InputStreamReader(is));
                String satir;
                String dosya = "";
                while ((satir = br.readLine()) != null) {
                    Log.d("satir:", satir);
                    dosya += satir;
                }
                //myList.add(Integer.valueOf(dosya));
                System.out.println("arraylistim");
                for (int i=0;i<myList.size();i++)
                {
                    System.out.println("kacinci:"+i+"  .. "+myList.get(i));

                }

                String dosyaa = "";



                String myurl = "https://us-central1-api1-13f97.cloudfunctions.net/getItems";
                URL newurl = new URL(myurl);
                connection = (HttpURLConnection) newurl.openConnection();
                connection.connect();
                InputStream iss = connection.getInputStream();
                brr = new BufferedReader(new InputStreamReader(iss));
                String satirr;

                while ((satirr = brr.readLine()) != null) {
                    Log.d("satirr:", satirr);
                    dosyaa += satirr;
                }
                System.out.println("....EKLENEN HABER DETAYİ...");

                System.out.println(dosyaa);

                JSONArray array = new JSONArray(dosyaa);
                for (int i=0;i<array.length();i++)
                {
                    JSONObject object = array.getJSONObject(i);
                    System.out.println("flt : " + flt);
                    if (flt != null && flt.equalsIgnoreCase(object.getString("kampanyaIcerigi"))) {
                        LatLng uzun = gps(object.getString("firmaLokasyon"));
                        Double lt = uzun.latitude;
                        Double lng1 = uzun.longitude;
                        double ms = addressCalculation(lat, alng, lt, lng1);
                        System.out.println("uzunluk(ms) :" + ms + "threshold :" + 1);
                        if (ms <= threshold) {
                            myList2.add(String.valueOf(object.getInt("firmaId")));
                            myList2.add(object.getString("firmaAdi"));
                            myList2.add(object.getString("firmaLokasyon"));
                            myList2.add(object.getString("kampanyaIcerigi"));
                            myList2.add(object.getString("kampanyaSuresi"));

                        }

                    } else {

                        LatLng uzun = gps(object.getString("firmaLokasyon"));
                        Double lt = uzun.latitude;
                        Double lng1 = uzun.longitude;
                        double ms = addressCalculation(lat, alng, lt, lng1);
                        System.out.println("uzunluk(ms) :" + ms + "threshold :" + threshold);
                        if (ms <= threshold) {
                            myList2.add(String.valueOf(object.getInt("firmaId")));
                            myList2.add(object.getString("firmaAdi"));
                            myList2.add(object.getString("firmaLokasyon"));
                            myList2.add(object.getString("kampanyaIcerigi"));
                            myList2.add(object.getString("kampanyaSuresi"));


                        }
                    }


                }

                notificationcall(myList2,(myList2.size()/5));
                return dosya;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return "hata";
        }


        @Override
        protected void onPostExecute(String s) {
            Log.d("posttan gelen",s);

        }

        public void notificationcall(List myList2,int sayi)
        {
            int count=0;

            for (int i=0;i<sayi;i++)
            {

                Intent intent = new Intent(getApplicationContext(), fGosterim.class);
                intent.putExtra("lat",lat);
                intent.putExtra("long",alng);
                intent.putExtra("threshold",threshold);
                intent.putExtra("kategori",flt);


                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                count++;

                PendingIntent resultpendingIntent = PendingIntent.getActivity(getApplicationContext(), (i+1), intent, PendingIntent.FLAG_UPDATE_CURRENT);
                NotificationCompat.Builder notificationBuilder = (NotificationCompat.Builder) new NotificationCompat.Builder(getApplicationContext())
                        .setDefaults(NotificationCompat.DEFAULT_ALL)
                        .setSmallIcon(R.drawable.ic_launcher_background)
                        .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher_background))
                        .setContentTitle("yeni bir haber eklendi")
                        .setContentText("haberi acmak icin dokun")
                        .setAutoCancel(true)
                        .setContentIntent(resultpendingIntent);

                NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                notificationManager.notify((i+1), notificationBuilder.build());
            }



        }
    }
    public LatLng gps( String strAddress) {

        Geocoder coder = new Geocoder(this);
        List<Address> address;
        LatLng p1 = null;

        try {
            // May throw an IOException
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return null;
            }

            Address location = address.get(0);
            p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }


        return p1;
    }
    private double addressCalculation(double lat1, double lon1, double lat2, double lon2) {
        double theta = lon1 - lon2;
        double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
        dist = Math.acos(dist);
        dist = rad2deg(dist);
        dist = dist * 60 * 1.1515;

        dist = dist * 1.609344;

        return (dist);
    }
    private double deg2rad(double deg) {
        return (deg * Math.PI / 180.0);
    }

    private double rad2deg(double rad) {
        return (rad * 180.0 / Math.PI);
    }


    @Override
    public void onDestroy() {//Servis stopService(); metoduyla durdurulduğunda çalışır
        timer.cancel();
        Toast.makeText(this, "Servis Durduruldu.Bu Mesaj Servis Class'dan", Toast.LENGTH_LONG).show();
    }

}