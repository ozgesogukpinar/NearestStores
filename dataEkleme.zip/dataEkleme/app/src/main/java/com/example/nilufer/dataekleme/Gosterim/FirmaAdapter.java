package com.example.nilufer.dataekleme.Gosterim;

import android.content.Context;
import android.graphics.Movie;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.nilufer.dataekleme.R;

import java.util.List;


public class FirmaAdapter extends RecyclerView.Adapter<FirmaAdapter.ViewHolder> {

    private Context context;
    private List<Firmalar> list;

    public FirmaAdapter(Context context, List<Firmalar> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.activity_single_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Firmalar firmalar = list.get(position);

        holder.firmaId.setText(firmalar.getFirmaid());
        holder.firmaAdi.setText(String.valueOf(firmalar.getFirmaAdi()));
        holder.firmaLokasyon.setText(String.valueOf(firmalar.getFirmaLokasyon()));
        holder.kampanyaIcerik.setText(String.valueOf(firmalar.getKampanyaIcerik()));
        holder.kampanyaSuresi.setText(String.valueOf(firmalar.getKampanyaSuresi()));

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView firmaId, firmaAdi, firmaLokasyon,kampanyaSuresi,kampanyaIcerik;

        public ViewHolder(View itemView) {
            super(itemView);

            firmaId = itemView.findViewById(R.id.firmaID);
            firmaAdi = itemView.findViewById(R.id.firmaAdi);
            firmaLokasyon = itemView.findViewById(R.id.firmaLokasyon);
            kampanyaIcerik = itemView.findViewById(R.id.kampanyaİcerigi);
            kampanyaSuresi = itemView.findViewById(R.id.kampanyaSuresi);

        }
    }

}

